--
-- PostgreSQL database dump
--

\restrict 2kRBtmtJkicfwKfdLfkN5SJdphRYeVGoOMd6Kcod1nJRh5l2bNxvANQgpYAoZbM

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.sponsorships DROP CONSTRAINT IF EXISTS "sponsorships_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.sponsorships DROP CONSTRAINT IF EXISTS "sponsorships_childId_fkey";
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS "sessions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_childId_fkey";
ALTER TABLE IF EXISTS ONLY public.cms_revisions DROP CONSTRAINT IF EXISTS "cms_revisions_pageId_fkey";
ALTER TABLE IF EXISTS ONLY public.cms_revisions DROP CONSTRAINT IF EXISTS "cms_revisions_authorId_fkey";
ALTER TABLE IF EXISTS ONLY public.cms_nav_items DROP CONSTRAINT IF EXISTS "cms_nav_items_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public.cms_media_assets DROP CONSTRAINT IF EXISTS "cms_media_assets_uploadedBy_fkey";
ALTER TABLE IF EXISTS ONLY public.cms_audit_logs DROP CONSTRAINT IF EXISTS "cms_audit_logs_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.cms_audit_logs DROP CONSTRAINT IF EXISTS "cms_audit_logs_pageId_fkey";
ALTER TABLE IF EXISTS ONLY public.child_updates DROP CONSTRAINT IF EXISTS "child_updates_childId_fkey";
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS "accounts_userId_fkey";
DROP INDEX IF EXISTS public.verification_tokens_token_key;
DROP INDEX IF EXISTS public.verification_tokens_identifier_token_key;
DROP INDEX IF EXISTS public.users_role_idx;
DROP INDEX IF EXISTS public."users_resetPasswordToken_key";
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public."users_createdAt_idx";
DROP INDEX IF EXISTS public.trustees_published_order_idx;
DROP INDEX IF EXISTS public.stories_published_order_idx;
DROP INDEX IF EXISTS public."sponsorships_userId_idx";
DROP INDEX IF EXISTS public."sponsorships_stripeSubscriptionId_key";
DROP INDEX IF EXISTS public.sponsorships_status_idx;
DROP INDEX IF EXISTS public."sponsorships_childId_idx";
DROP INDEX IF EXISTS public."sessions_userId_idx";
DROP INDEX IF EXISTS public."sessions_sessionToken_key";
DROP INDEX IF EXISTS public."partnership_inquiries_status_createdAt_idx";
DROP INDEX IF EXISTS public.impact_stats_published_order_idx;
DROP INDEX IF EXISTS public.history_events_published_order_idx;
DROP INDEX IF EXISTS public."donations_userId_idx";
DROP INDEX IF EXISTS public."donations_stripeSubscriptionId_idx";
DROP INDEX IF EXISTS public."donations_stripePaymentIntentId_key";
DROP INDEX IF EXISTS public."donations_stripeInvoiceId_key";
DROP INDEX IF EXISTS public."donations_stripeCheckoutSessionId_key";
DROP INDEX IF EXISTS public."donations_status_createdAt_idx";
DROP INDEX IF EXISTS public."donations_paymentMethod_status_idx";
DROP INDEX IF EXISTS public."donations_momoReference_key";
DROP INDEX IF EXISTS public."donations_childId_idx";
DROP INDEX IF EXISTS public."cms_revisions_pageId_revisionNumber_key";
DROP INDEX IF EXISTS public."cms_revisions_pageId_idx";
DROP INDEX IF EXISTS public."cms_revisions_authorId_idx";
DROP INDEX IF EXISTS public.cms_pages_status_idx;
DROP INDEX IF EXISTS public.cms_pages_slug_key;
DROP INDEX IF EXISTS public.cms_pages_slug_idx;
DROP INDEX IF EXISTS public.cms_nav_items_menu_published_order_idx;
DROP INDEX IF EXISTS public.cms_media_assets_url_key;
DROP INDEX IF EXISTS public."cms_media_assets_uploadedBy_idx";
DROP INDEX IF EXISTS public."cms_media_assets_mimeType_idx";
DROP INDEX IF EXISTS public.cms_media_assets_folder_idx;
DROP INDEX IF EXISTS public."cms_media_assets_createdAt_idx";
DROP INDEX IF EXISTS public."cms_audit_logs_userId_idx";
DROP INDEX IF EXISTS public."cms_audit_logs_pageId_idx";
DROP INDEX IF EXISTS public."cms_audit_logs_createdAt_idx";
DROP INDEX IF EXISTS public.cms_audit_logs_action_idx;
DROP INDEX IF EXISTS public.children_status_idx;
DROP INDEX IF EXISTS public.children_slug_key;
DROP INDEX IF EXISTS public.children_featured_order_idx;
DROP INDEX IF EXISTS public.children_archived_idx;
DROP INDEX IF EXISTS public."child_updates_childId_published_idx";
DROP INDEX IF EXISTS public."accounts_userId_idx";
DROP INDEX IF EXISTS public."accounts_provider_providerAccountId_key";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.trustees DROP CONSTRAINT IF EXISTS trustees_pkey;
ALTER TABLE IF EXISTS ONLY public.stories DROP CONSTRAINT IF EXISTS stories_pkey;
ALTER TABLE IF EXISTS ONLY public.sponsorships DROP CONSTRAINT IF EXISTS sponsorships_pkey;
ALTER TABLE IF EXISTS ONLY public.site_settings DROP CONSTRAINT IF EXISTS site_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.partnership_inquiries DROP CONSTRAINT IF EXISTS partnership_inquiries_pkey;
ALTER TABLE IF EXISTS ONLY public.impact_stats DROP CONSTRAINT IF EXISTS impact_stats_pkey;
ALTER TABLE IF EXISTS ONLY public.history_events DROP CONSTRAINT IF EXISTS history_events_pkey;
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS donations_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_revisions DROP CONSTRAINT IF EXISTS cms_revisions_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_pages DROP CONSTRAINT IF EXISTS cms_pages_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_nav_items DROP CONSTRAINT IF EXISTS cms_nav_items_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_media_assets DROP CONSTRAINT IF EXISTS cms_media_assets_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_audit_logs DROP CONSTRAINT IF EXISTS cms_audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_appearance DROP CONSTRAINT IF EXISTS cms_appearance_pkey;
ALTER TABLE IF EXISTS ONLY public.children DROP CONSTRAINT IF EXISTS children_pkey;
ALTER TABLE IF EXISTS ONLY public.child_updates DROP CONSTRAINT IF EXISTS child_updates_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.verification_tokens;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.trustees;
DROP TABLE IF EXISTS public.stories;
DROP TABLE IF EXISTS public.sponsorships;
DROP TABLE IF EXISTS public.site_settings;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.partnership_inquiries;
DROP TABLE IF EXISTS public.impact_stats;
DROP TABLE IF EXISTS public.history_events;
DROP TABLE IF EXISTS public.donations;
DROP TABLE IF EXISTS public.cms_revisions;
DROP TABLE IF EXISTS public.cms_pages;
DROP TABLE IF EXISTS public.cms_nav_items;
DROP TABLE IF EXISTS public.cms_media_assets;
DROP TABLE IF EXISTS public.cms_audit_logs;
DROP TABLE IF EXISTS public.cms_appearance;
DROP TABLE IF EXISTS public.children;
DROP TABLE IF EXISTS public.child_updates;
DROP TABLE IF EXISTS public.accounts;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TYPE IF EXISTS public."SponsorshipType";
DROP TYPE IF EXISTS public."SponsorshipStatus";
DROP TYPE IF EXISTS public."Role";
DROP TYPE IF EXISTS public."PaymentMethod";
DROP TYPE IF EXISTS public."PartnershipType";
DROP TYPE IF EXISTS public."PageStatus";
DROP TYPE IF EXISTS public."NavMenu";
DROP TYPE IF EXISTS public."InquiryStatus";
DROP TYPE IF EXISTS public."Gender";
DROP TYPE IF EXISTS public."DonationStatus";
DROP TYPE IF EXISTS public."DonationFrequency";
DROP TYPE IF EXISTS public."DonationDesignation";
DROP TYPE IF EXISTS public."ChildStatus";
--
-- Name: ChildStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ChildStatus" AS ENUM (
    'AVAILABLE',
    'SPONSORED',
    'GRADUATED'
);


--
-- Name: DonationDesignation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DonationDesignation" AS ENUM (
    'GENERAL',
    'CHILD_SPONSORSHIP',
    'PARTNERSHIP'
);


--
-- Name: DonationFrequency; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DonationFrequency" AS ENUM (
    'ONE_TIME',
    'MONTHLY'
);


--
-- Name: DonationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DonationStatus" AS ENUM (
    'PENDING',
    'SUCCEEDED',
    'FAILED',
    'REFUNDED'
);


--
-- Name: Gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Gender" AS ENUM (
    'MALE',
    'FEMALE'
);


--
-- Name: InquiryStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InquiryStatus" AS ENUM (
    'NEW',
    'CONTACTED',
    'CLOSED'
);


--
-- Name: NavMenu; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NavMenu" AS ENUM (
    'HEADER',
    'FOOTER_COL1',
    'FOOTER_COL2',
    'FOOTER_COL3',
    'FOOTER_LEGAL'
);


--
-- Name: PageStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PageStatus" AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'ARCHIVED'
);


--
-- Name: PartnershipType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PartnershipType" AS ENUM (
    'INDIVIDUAL',
    'GROUP',
    'CORPORATE',
    'CHURCH',
    'WILL_GIFT',
    'VOLUNTEER'
);


--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CARD',
    'MOBILE_MONEY'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'DONOR',
    'STAFF',
    'ADMIN'
);


--
-- Name: SponsorshipStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SponsorshipStatus" AS ENUM (
    'ACTIVE',
    'PAUSED',
    'ENDED'
);


--
-- Name: SponsorshipType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SponsorshipType" AS ENUM (
    'FULL',
    'CONTRIBUTION'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: child_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.child_updates (
    id text NOT NULL,
    "childId" text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    "imageUrl" text,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: children; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.children (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    gender public."Gender" NOT NULL,
    "dateOfBirth" timestamp(3) without time zone,
    bio text NOT NULL,
    "photoUrl" text,
    school text,
    location text,
    status public."ChildStatus" DEFAULT 'AVAILABLE'::public."ChildStatus" NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "fundingGoalCents" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: cms_appearance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_appearance (
    id integer DEFAULT 1 NOT NULL,
    "primaryColor" text DEFAULT '#0f766e'::text NOT NULL,
    "secondaryColor" text DEFAULT '#d97706'::text NOT NULL,
    "accentColor" text DEFAULT '#f59e0b'::text NOT NULL,
    "fontHeading" text DEFAULT 'font-heading'::text NOT NULL,
    "fontBody" text DEFAULT 'font-sans'::text NOT NULL,
    "buttonRadius" text DEFAULT 'rounded-xl'::text NOT NULL,
    "containerWidth" text DEFAULT 'max-w-7xl'::text NOT NULL,
    "headerSticky" boolean DEFAULT true NOT NULL,
    "footerTheme" text DEFAULT 'dark'::text NOT NULL,
    "logoUrl" text,
    "logoDarkUrl" text,
    "faviconUrl" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: cms_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_audit_logs (
    id text NOT NULL,
    "pageId" text,
    "userId" text,
    "userName" text,
    action text NOT NULL,
    details jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: cms_media_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_media_assets (
    id text NOT NULL,
    url text NOT NULL,
    filename text NOT NULL,
    "originalName" text NOT NULL,
    "mimeType" text NOT NULL,
    "sizeBytes" integer NOT NULL,
    width integer,
    height integer,
    "altText" text,
    caption text,
    folder text DEFAULT 'general'::text NOT NULL,
    "uploadedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: cms_nav_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_nav_items (
    id text NOT NULL,
    menu public."NavMenu" DEFAULT 'HEADER'::public."NavMenu" NOT NULL,
    label text NOT NULL,
    href text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "isExternal" boolean DEFAULT false NOT NULL,
    published boolean DEFAULT true NOT NULL,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: cms_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_pages (
    id text NOT NULL,
    slug text NOT NULL,
    title text NOT NULL,
    "publicTitle" text,
    description text,
    status public."PageStatus" DEFAULT 'DRAFT'::public."PageStatus" NOT NULL,
    "publishedRevisionId" text,
    "isSystem" boolean DEFAULT false NOT NULL,
    "seoTitle" text,
    "seoDescription" text,
    "ogImageUrl" text,
    "canonicalUrl" text,
    "noIndex" boolean DEFAULT false NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: cms_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_revisions (
    id text NOT NULL,
    "pageId" text NOT NULL,
    "revisionNumber" integer NOT NULL,
    "authorId" text,
    "authorName" text,
    sections jsonb NOT NULL,
    changelog text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: donations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donations (
    id text NOT NULL,
    "userId" text,
    "childId" text,
    title text,
    "donorName" text NOT NULL,
    "donorEmail" text NOT NULL,
    "donorPhone" text,
    anonymous boolean DEFAULT false NOT NULL,
    "amountCents" integer NOT NULL,
    currency text DEFAULT 'usd'::text NOT NULL,
    frequency public."DonationFrequency" NOT NULL,
    designation public."DonationDesignation" DEFAULT 'GENERAL'::public."DonationDesignation" NOT NULL,
    status public."DonationStatus" DEFAULT 'PENDING'::public."DonationStatus" NOT NULL,
    "paymentMethod" public."PaymentMethod" DEFAULT 'CARD'::public."PaymentMethod" NOT NULL,
    "emailUpdates" boolean DEFAULT true NOT NULL,
    "smsUpdates" boolean DEFAULT false NOT NULL,
    "whatsappUpdates" boolean DEFAULT false NOT NULL,
    "stripeCheckoutSessionId" text,
    "stripeInvoiceId" text,
    "stripePaymentIntentId" text,
    "stripeSubscriptionId" text,
    "stripeCustomerId" text,
    "momoReference" text,
    "momoVerifiedAt" timestamp(3) without time zone,
    "momoVerifiedBy" text,
    "momoRejectionReason" text,
    "exchangeRate" double precision,
    "amountGhsCents" integer,
    "receiptSentAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: history_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.history_events (
    id text NOT NULL,
    year text NOT NULL,
    title text NOT NULL,
    "bulletPoints" text[] DEFAULT ARRAY[]::text[],
    "imageUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: impact_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.impact_stats (
    id text NOT NULL,
    label text NOT NULL,
    value text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: partnership_inquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partnership_inquiries (
    id text NOT NULL,
    type public."PartnershipType" NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text,
    status public."InquiryStatus" DEFAULT 'NEW'::public."InquiryStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id integer DEFAULT 1 NOT NULL,
    "heroHeadline" text DEFAULT 'Transforming Lives Through Education'::text NOT NULL,
    "heroSubheadline" text DEFAULT 'Providing access to education for a brighter future'::text NOT NULL,
    "missionTitle" text DEFAULT 'Our Guiding Mission'::text NOT NULL,
    "missionBody" text DEFAULT ''::text NOT NULL,
    "facebookUrl" text,
    "twitterUrl" text,
    "youtubeUrl" text,
    "contactEmail" text,
    "contactPhone" text,
    "momoProvider" text DEFAULT 'MTN Mobile Money'::text,
    "momoNumber" text,
    "momoName" text,
    "momoRateUsdToGhs" double precision DEFAULT 15.5,
    "momoInstructions" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: sponsorships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sponsorships (
    id text NOT NULL,
    "userId" text,
    "childId" text NOT NULL,
    "guestName" text,
    "guestEmail" text,
    "guestPhone" text,
    type public."SponsorshipType" NOT NULL,
    status public."SponsorshipStatus" DEFAULT 'ACTIVE'::public."SponsorshipStatus" NOT NULL,
    "stripeSubscriptionId" text,
    "monthlyAmountCents" integer NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: stories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stories (
    id text NOT NULL,
    name text NOT NULL,
    age integer,
    quote text NOT NULL,
    "mediaUrl" text,
    "imageUrl" text,
    published boolean DEFAULT true NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: trustees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trustees (
    id text NOT NULL,
    name text NOT NULL,
    "photoUrl" text,
    title text,
    "order" integer DEFAULT 0 NOT NULL,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    phone text,
    "passwordHash" text,
    role public."Role" DEFAULT 'DONOR'::public."Role" NOT NULL,
    "resetPasswordToken" text,
    "resetPasswordExpires" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
a217dc21-e5fd-45c7-95af-fcfd668fd49b	72f9fec37ee94dc35d510486d37e98c906dc10fbc817b9eacae585baa0b8e14b	2026-11-10 12:28:49.564589+00	20260830045522_init		\N	2026-11-10 12:28:49.564589+00	0
e00d675c-482c-425b-8853-6cc67a1861ce	c1d78306426007fa750160cc14d9531d69050e15fe1ae886eea5d4a5f4336693	2026-11-10 12:28:50.416325+00	20260830110505_child_funding_goal		\N	2026-11-10 12:28:50.416325+00	0
0ea7467b-61e8-401c-be79-c74b9c66ac92	e1fd014526182a471a9281d1c284d294ac4f1b6b679d40deaf175f7287171809	2026-11-10 12:28:51.258444+00	20260902120000_child_updates_and_momo		\N	2026-11-10 12:28:51.258444+00	0
a4ea178d-fc01-4f37-bc3d-6b842ef3d009	36609953bc5ad97a13ed6fbae7f265a3842bad172b0d2bfc087fbbaa52b395c1	2026-11-10 12:28:52.091549+00	20261110090000_financial_integrity_and_security		\N	2026-11-10 12:28:52.091549+00	0
aa4c711a-ab6b-4731-b43f-d9ea5f3a68ed	3fb3f84c2ee8c40d83f8dc3e60809f908c14418bd3a2dbcd25adcde8cae6003e	2026-11-10 12:28:52.933321+00	20261110110000_cms_architecture		\N	2026-11-10 12:28:52.933321+00	0
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: child_updates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.child_updates (id, "childId", title, body, "imageUrl", published, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: children; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.children (id, slug, name, gender, "dateOfBirth", bio, "photoUrl", school, location, status, featured, archived, "order", "fundingGoalCents", "createdAt", "updatedAt") FROM stdin;
cmwakehas0001pb9kis5j4x7j	amara	Amara	FEMALE	\N	Amara loves to read and dreams of becoming a teacher one day. She recently started school for the first time thanks to a LivingHope sponsor.	\N	Accra Community School	Accra, Ghana	AVAILABLE	t	f	0	0	2026-11-10 10:46:14.548	2026-11-10 10:46:14.548
cmwakehay0002pb9kumycfp7u	kwame	Kwame	MALE	\N	Kwame is a bright, curious 10-year-old who wants to learn how things work. He's currently enrolled in a vocational carpentry program.	\N	Tema Vocational Institute	Tema, Ghana	AVAILABLE	f	f	0	0	2026-11-10 10:46:14.554	2026-11-10 10:46:14.554
cmwakehb20003pb9k4jb1wjmf	efua	Efua	FEMALE	\N	Efua is full of energy and loves to sing. With your support, she can continue her education and pursue her passion for music.	\N	Kumasi Primary School	Kumasi, Ghana	AVAILABLE	f	f	0	0	2026-11-10 10:46:14.558	2026-11-10 10:46:14.558
\.


--
-- Data for Name: cms_appearance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_appearance (id, "primaryColor", "secondaryColor", "accentColor", "fontHeading", "fontBody", "buttonRadius", "containerWidth", "headerSticky", "footerTheme", "logoUrl", "logoDarkUrl", "faviconUrl", "updatedAt") FROM stdin;
\.


--
-- Data for Name: cms_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_audit_logs (id, "pageId", "userId", "userName", action, details, "createdAt") FROM stdin;
\.


--
-- Data for Name: cms_media_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_media_assets (id, url, filename, "originalName", "mimeType", "sizeBytes", width, height, "altText", caption, folder, "uploadedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: cms_nav_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_nav_items (id, menu, label, href, "order", "isExternal", published, "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: cms_pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_pages (id, slug, title, "publicTitle", description, status, "publishedRevisionId", "isSystem", "seoTitle", "seoDescription", "ogImageUrl", "canonicalUrl", "noIndex", "publishedAt", "createdAt", "updatedAt") FROM stdin;
cmwakmaa800005l9k7ddmmm4c	home	Homepage	LivingHope — Restoring Hope to Children in Ghana	Nonprofit charity supporting street-connected children in Ghana	PUBLISHED	cmwakmaaf00015l9kteeowc28	t	\N	\N	\N	\N	f	2026-11-10 10:52:18.697	2026-11-10 10:52:18.704	2026-11-10 10:52:18.717
cmwakmaao00025l9ktb7ku5zv	about	About Us	About LivingHope Ghana	Our history, faith, mission, and leadership team in Accra, Ghana	PUBLISHED	cmwakmaap00035l9kei24e2wt	t	\N	\N	\N	\N	f	2026-11-10 10:52:18.72	2026-11-10 10:52:18.72	2026-11-10 10:52:18.723
cmwakmaat00045l9ks3wmei6s	what-we-do	What We Do	Our Programmes & Community Interventions	Street outreach, schooling, and vocational training programmes in Ghana	PUBLISHED	cmwakmaau00055l9klndwnguo	t	\N	\N	\N	\N	f	2026-11-10 10:52:18.725	2026-11-10 10:52:18.725	2026-11-10 10:52:18.728
\.


--
-- Data for Name: cms_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_revisions (id, "pageId", "revisionNumber", "authorId", "authorName", sections, changelog, "createdAt") FROM stdin;
cmwakmaaf00015l9kteeowc28	cmwakmaa800005l9k7ddmmm4c	1	\N	System Seed	[{"id": "sec_home_hero", "type": "hero", "props": {"badge": "Hope for Vulnerable Children in Ghana", "title": "Transforming Lives Through Love & Education", "imageUrl": "/images/placeholders/home-hero.webp", "subtitle": "Providing food, shelter, school uniforms, and vocational training to street-connected children in Accra and beyond.", "alignment": "center", "primaryCta": {"href": "/sponsor-a-child", "label": "Sponsor a Child"}, "secondaryCta": {"href": "/donate", "label": "Make a Donation"}}, "enabled": true}, {"id": "sec_home_mission", "type": "rich_text", "props": {"content": "LivingHope exists to rescue, educate, and empower street-connected and underprivileged children across Ghana. We believe that poverty should never dictate a child's destiny. Through rigorous academic sponsorship, vocational training, holistic mentorship, and community reintegration, we are breaking cycles of generational poverty one life at a time.", "heading": "Our Guiding Mission", "subheading": "A calling rooted in faith, compassion, and sustainable community empowerment", "containerWidth": "default", "backgroundColor": "brand"}, "enabled": true}, {"id": "sec_home_stats", "type": "impact_stats", "props": {"heading": "Our Collective Impact to Date", "subheading": "Real, audited outcomes made possible by the generosity of donors worldwide", "customStats": [{"label": "Children Enrolled in School", "value": "450+"}, {"label": "Direct Support Allocation", "value": "100%"}, {"label": "Communities Served in Greater Accra", "value": "12"}, {"label": "Vocational Graduates", "value": "85+"}], "useLiveDatabase": true}, "enabled": true}, {"id": "sec_home_need", "type": "image_text", "props": {"cta": {"href": "/what-we-do", "label": "Read About Our Approach"}, "lead": "Thousands of children in Accra sleep on curbs, sell sachets of water at traffic lights, and miss out on basic schooling.", "heading": "The Urgency of Our Mission", "imageAlt": "Street child looking with hope toward a better future", "imageUrl": "/images/placeholders/street-child.webp", "paragraphs": ["In urban Ghana, extreme poverty and family displacement force children onto the streets as early as age six. Without intervention, they face exploitation, malnutrition, and a lifetime without literacy.", "LivingHope provides a secure sanctuary, immediate health interventions, daily nutritious meals, and the loving support needed to re-enter formal schooling."], "bulletPoints": ["Safe shelter and daily warm meals", "Full school enrollment, books, and uniforms", "Continuous healthcare, counselling, and spiritual guidance", "Family tracing, mediation, and sustainable reunification"], "imagePosition": "right"}, "enabled": true}, {"id": "sec_home_how_helps", "type": "card_grid", "props": {"cards": [{"icon": "GraduationCap", "link": {"href": "/what-we-do", "label": "Learn More"}, "title": "Education & Literacy", "description": "Tuition fees, textbooks, school uniforms, and dedicated after-school remedial tutoring."}, {"icon": "HeartHandshake", "link": {"href": "/what-we-do", "label": "Learn More"}, "title": "Nutrition & Medical Care", "description": "Daily balanced lunches, annual medical checkups, dental screening, and emergency healthcare coverage."}, {"icon": "Hammer", "link": {"href": "/what-we-do", "label": "Learn More"}, "title": "Vocational Skills", "description": "Carpentry, sewing, IT training, and small business apprenticeships for older youth transitioning to adulthood."}], "columns": 3, "heading": "How Your Support Changes Everything", "subheading": "Every dollar invested yields tangible, lasting transformation in a child's life"}, "enabled": true}, {"id": "sec_home_featured_children", "type": "featured_children", "props": {"mode": "auto_urgent", "heading": "Children Awaiting a Brightener", "maxCount": 3, "subheading": "Meet the incredible boys and girls who need your sponsorship today"}, "enabled": true}, {"id": "sec_home_stories", "type": "featured_stories", "props": {"heading": "Stories of Transformation", "subheading": "Witness how sponsorship and compassion changed their trajectories forever", "showRecentDonors": true}, "enabled": true}, {"id": "sec_home_brightener_cta", "type": "partnership_cta", "props": {"heading": "Become a Brightener Partner", "buttonUrl": "/become-a-brightener", "subheading": "Whether you are an individual, church, foundation, or corporate team, your sustained partnership creates enduring community resilience.", "buttonLabel": "Explore Brightener Partnerships", "backgroundImageUrl": "/images/placeholders/partnership-banner.webp"}, "enabled": true}, {"id": "sec_home_donation_cta", "type": "donation_cta", "props": {"heading": "Every Child Deserves a Chance to Learn", "subheading": "Your tax-deductible gift directly funds education, food, and security for Ghana's most vulnerable children.", "accentColor": "#0f766e", "presetAmounts": [25, 50, 100, 250], "primaryCtaLabel": "Make an Immediate Donation"}, "enabled": true}]	Default Initial Homepage	2026-11-10 10:52:18.711
cmwakmaap00035l9kei24e2wt	cmwakmaao00025l9ktb7ku5zv	1	\N	System Seed	[{"id": "sec_about_hero", "type": "hero", "props": {"badge": "Founded on Faith & Integrity", "title": "About LivingHope Ghana", "imageUrl": "/images/placeholders/about-hero.webp", "subtitle": "Dedicated to rescuing, educating, and uplifting vulnerable street-connected children across Greater Accra since 2012.", "alignment": "center"}, "enabled": true}, {"id": "sec_about_who", "type": "image_text", "props": {"lead": "LivingHope is a registered Christian non-profit non-governmental organization operating on the ground in Accra, Ghana.", "heading": "Who We Are", "imageAlt": "LivingHope field workers interacting with children", "imageUrl": "/images/placeholders/team-field.webp", "paragraphs": ["We partner directly with local schools, traditional community elders, social welfare departments, and international donors to build sustainable rescue and education pathways for children who have fallen through society's safety nets.", "Our team consists of passionate Ghanaian social workers, certified teachers, counsellors, and international volunteers united by a shared vision of zero children living or working on the streets."], "bulletPoints": ["100% field-tested transparency and financial accountability", "Deep collaboration with Ghanaian municipal welfare agencies", "Holistic development: spiritual, educational, emotional, physical"], "imagePosition": "left"}, "enabled": true}, {"id": "sec_about_values", "type": "card_grid", "props": {"cards": [{"icon": "Heart", "title": "Faith", "description": "Rooted in Christ-like love, compassion, and servant leadership for all people."}, {"icon": "Flame", "title": "Passion", "description": "Relentless enthusiasm for justice, child protection, and holistic community uplift."}, {"icon": "ShieldCheck", "title": "Diligence", "description": "Uncompromising work ethic in education, child safety, and donor stewardship."}, {"icon": "Clock", "title": "Dependability", "description": "Consistent follow-through in keeping promises to every child and supporter."}, {"icon": "Users", "title": "Collaboration", "description": "Uniting donors, communities, and local authorities for lasting impact."}], "columns": 3, "heading": "Our Guiding Values", "subheading": "The core principles that govern our decisions, actions, and stewardship"}, "enabled": true}]	Default Initial About Page	2026-11-10 10:52:18.721
cmwakmaau00055l9klndwnguo	cmwakmaat00045l9ks3wmei6s	1	\N	System Seed	[{"id": "sec_wwd_hero", "type": "hero", "props": {"badge": "Holistic Intervention Model", "title": "Connecting Generous People to Needy Children", "imageUrl": "/images/placeholders/what-we-do-hero.webp", "subtitle": "We bridge the gap between compassionate global donors and children who lack access to food, schooling, and medical attention.", "alignment": "center", "primaryCta": {"href": "/sponsor-a-child", "label": "Sponsor a Child"}, "secondaryCta": {"href": "/donate", "label": "Support Our Work"}}, "enabled": true}, {"id": "sec_wwd_programmes", "type": "programmes", "props": {"heading": "Our Primary Programmes", "programmes": [{"title": "Street Outreach & First Contact", "metrics": "Over 600 children engaged annually", "category": "Rescue & Shelter", "description": "Mobile outreach teams visit market stalls and traffic junctions to build trust, provide immediate first aid and food, and invite children to daytime drop-in centres."}, {"title": "Formal School Enrollment", "metrics": "450+ students currently enrolled in basic school", "category": "Education", "description": "We pay school enrollment fees, purchase prescribed uniforms and textbooks, provide desks and bags, and pair students with after-school remedial tutors."}, {"title": "Vocational Skills & Apprenticeships", "metrics": "85+ certified graduates working independently", "category": "Livelihood", "description": "Older youth learn carpentry, masonry, sewing, coding, and culinary arts under certified master craftspeople to secure independent, dignified employment."}], "subheading": "Structured pathways designed to walk with children from the street to self-sufficiency"}, "enabled": true}, {"id": "sec_wwd_faq", "type": "faq", "props": {"items": [{"answer": "Children are identified through field outreach in high-density informal settlements and market areas in Accra. Our licensed social workers conduct extensive home assessments and vulnerability scoring before formal enrollment.", "question": "How do you select which children receive support?"}, {"answer": "100% of recurring monthly child sponsorships go directly to the child's school fees, nutrition, and healthcare. Core administrative costs are funded separately by dedicated foundational grants and private board gifts.", "question": "How are donations allocated across administrative and field expenses?"}, {"answer": "Yes! We coordinate termly letters, drawings, and academic report cards. Monitored video updates and visits to our Accra centre can be arranged through our sponsorship coordinators with child safeguarding clearance.", "question": "Can I correspond with or visit my sponsored child?"}], "heading": "Frequently Asked Questions", "subheading": "Everything you need to know about our programmes and operational integrity"}, "enabled": true}]	Default Initial What We Do Page	2026-11-10 10:52:18.726
\.


--
-- Data for Name: donations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donations (id, "userId", "childId", title, "donorName", "donorEmail", "donorPhone", anonymous, "amountCents", currency, frequency, designation, status, "paymentMethod", "emailUpdates", "smsUpdates", "whatsappUpdates", "stripeCheckoutSessionId", "stripeInvoiceId", "stripePaymentIntentId", "stripeSubscriptionId", "stripeCustomerId", "momoReference", "momoVerifiedAt", "momoVerifiedBy", "momoRejectionReason", "exchangeRate", "amountGhsCents", "receiptSentAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: history_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.history_events (id, year, title, "bulletPoints", "imageUrl", "order", published, "createdAt", "updatedAt") FROM stdin;
cmwakehbl0006pb9k8ek1ml8g	2010	Launched SheltaAfrica NGO	{"Preach Jesus Christ to street dwellers.","Provide free meals.","Provide health care.","Provide start-up capital for petty trading.","Sponsor children's education."}	\N	0	t	2026-11-10 10:46:14.577	2026-11-10 10:46:14.577
cmwakehbp0007pb9ktj4ome0h	2015	Expanded Our Reach	{"Preach Jesus Christ to street dwellers.","Provide free meals.","Sponsor children's education.","Provide vocational training opportunities."}	\N	1	t	2026-11-10 10:46:14.581	2026-11-10 10:46:14.581
cmwakehbs0008pb9kphgk5p8k	2025	Launched LivingHope	{"Scale up education sponsorship using digital media.","Preach Jesus Christ to street dwellers.","Provide free meals.","Provide health care.","Provide start-up capital for petty trading."}	\N	2	t	2026-11-10 10:46:14.584	2026-11-10 10:46:14.584
\.


--
-- Data for Name: impact_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.impact_stats (id, label, value, "order", published, "createdAt", "updatedAt") FROM stdin;
cmwakehbg0005pb9kws4pq62s	Street Children provided with education / vocational training	20+	0	t	2026-11-10 10:46:14.572	2026-11-10 10:46:14.572
\.


--
-- Data for Name: partnership_inquiries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.partnership_inquiries (id, type, name, email, phone, message, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, "sessionToken", "userId", expires) FROM stdin;
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (id, "heroHeadline", "heroSubheadline", "missionTitle", "missionBody", "facebookUrl", "twitterUrl", "youtubeUrl", "contactEmail", "contactPhone", "momoProvider", "momoNumber", "momoName", "momoRateUsdToGhs", "momoInstructions", "updatedAt") FROM stdin;
1	Transforming Lives Through Education	Providing access to education for a brighter future	Our Guiding Mission	At LivingHope, we are dedicated to transforming the lives of street children by providing comprehensive access to quality education. We foster environments where every child can discover their innate potential, cultivate their talents, and build a foundation for a brighter, self-sufficient future.	\N	\N	\N	hello@livinghope.org	\N	MTN Mobile Money	\N	\N	15.5	\N	2026-11-10 10:46:14.178
\.


--
-- Data for Name: sponsorships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sponsorships (id, "userId", "childId", "guestName", "guestEmail", "guestPhone", type, status, "stripeSubscriptionId", "monthlyAmountCents", "startDate", "endDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: stories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stories (id, name, age, quote, "mediaUrl", "imageUrl", published, "order", "createdAt", "updatedAt") FROM stdin;
cmwakehbb0004pb9kqdmd2faj	Amara	12	Receiving books and a uniform meant I could finally attend school. This education is the greatest gift I have ever received.	\N	\N	t	0	2026-11-10 10:46:14.567	2026-11-10 10:46:14.567
\.


--
-- Data for Name: trustees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trustees (id, name, "photoUrl", title, "order", published, "createdAt", "updatedAt") FROM stdin;
cmwakehbw0009pb9kx38f2tik	Seyram Akotey	\N	\N	0	t	2026-11-10 10:46:14.588	2026-11-10 10:46:14.588
cmwakehbx000apb9k517zbvg2	Angela Farley	\N	\N	1	t	2026-11-10 10:46:14.589	2026-11-10 10:46:14.589
cmwakehby000bpb9k7aaqibm1	CK Bruce	\N	\N	2	t	2026-11-10 10:46:14.59	2026-11-10 10:46:14.59
cmwakehc0000cpb9kft9vjrf3	Cobby Washington	\N	\N	3	t	2026-11-10 10:46:14.592	2026-11-10 10:46:14.592
cmwakehc1000dpb9kq961ikgl	Frank Bediako	\N	\N	4	t	2026-11-10 10:46:14.593	2026-11-10 10:46:14.593
cmwakehc3000epb9kdk9ycca6	Clifford Frempong	\N	\N	5	t	2026-11-10 10:46:14.595	2026-11-10 10:46:14.595
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, "emailVerified", image, phone, "passwordHash", role, "resetPasswordToken", "resetPasswordExpires", "createdAt", "updatedAt") FROM stdin;
cmwakehai0000pb9kt2w10sdw	LivingHope Admin	admin@livinghope.org	\N	\N	\N	$2b$12$blpnwVJ4PRpVHBPekOHdh.bC0at53gfcTNJAmbcFS0g8xHXxRhI96	ADMIN	\N	\N	2026-11-10 10:46:14.538	2026-11-10 10:46:14.538
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: child_updates child_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.child_updates
    ADD CONSTRAINT child_updates_pkey PRIMARY KEY (id);


--
-- Name: children children_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.children
    ADD CONSTRAINT children_pkey PRIMARY KEY (id);


--
-- Name: cms_appearance cms_appearance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_appearance
    ADD CONSTRAINT cms_appearance_pkey PRIMARY KEY (id);


--
-- Name: cms_audit_logs cms_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_audit_logs
    ADD CONSTRAINT cms_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: cms_media_assets cms_media_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_media_assets
    ADD CONSTRAINT cms_media_assets_pkey PRIMARY KEY (id);


--
-- Name: cms_nav_items cms_nav_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_nav_items
    ADD CONSTRAINT cms_nav_items_pkey PRIMARY KEY (id);


--
-- Name: cms_pages cms_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pages
    ADD CONSTRAINT cms_pages_pkey PRIMARY KEY (id);


--
-- Name: cms_revisions cms_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_revisions
    ADD CONSTRAINT cms_revisions_pkey PRIMARY KEY (id);


--
-- Name: donations donations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT donations_pkey PRIMARY KEY (id);


--
-- Name: history_events history_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.history_events
    ADD CONSTRAINT history_events_pkey PRIMARY KEY (id);


--
-- Name: impact_stats impact_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.impact_stats
    ADD CONSTRAINT impact_stats_pkey PRIMARY KEY (id);


--
-- Name: partnership_inquiries partnership_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partnership_inquiries
    ADD CONSTRAINT partnership_inquiries_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: sponsorships sponsorships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sponsorships
    ADD CONSTRAINT sponsorships_pkey PRIMARY KEY (id);


--
-- Name: stories stories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_pkey PRIMARY KEY (id);


--
-- Name: trustees trustees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trustees
    ADD CONSTRAINT trustees_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: accounts_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "accounts_provider_providerAccountId_key" ON public.accounts USING btree (provider, "providerAccountId");


--
-- Name: accounts_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "accounts_userId_idx" ON public.accounts USING btree ("userId");


--
-- Name: child_updates_childId_published_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "child_updates_childId_published_idx" ON public.child_updates USING btree ("childId", published);


--
-- Name: children_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX children_archived_idx ON public.children USING btree (archived);


--
-- Name: children_featured_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX children_featured_order_idx ON public.children USING btree (featured, "order");


--
-- Name: children_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX children_slug_key ON public.children USING btree (slug);


--
-- Name: children_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX children_status_idx ON public.children USING btree (status);


--
-- Name: cms_audit_logs_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_audit_logs_action_idx ON public.cms_audit_logs USING btree (action);


--
-- Name: cms_audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cms_audit_logs_createdAt_idx" ON public.cms_audit_logs USING btree ("createdAt");


--
-- Name: cms_audit_logs_pageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cms_audit_logs_pageId_idx" ON public.cms_audit_logs USING btree ("pageId");


--
-- Name: cms_audit_logs_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cms_audit_logs_userId_idx" ON public.cms_audit_logs USING btree ("userId");


--
-- Name: cms_media_assets_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cms_media_assets_createdAt_idx" ON public.cms_media_assets USING btree ("createdAt");


--
-- Name: cms_media_assets_folder_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_media_assets_folder_idx ON public.cms_media_assets USING btree (folder);


--
-- Name: cms_media_assets_mimeType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cms_media_assets_mimeType_idx" ON public.cms_media_assets USING btree ("mimeType");


--
-- Name: cms_media_assets_uploadedBy_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cms_media_assets_uploadedBy_idx" ON public.cms_media_assets USING btree ("uploadedBy");


--
-- Name: cms_media_assets_url_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cms_media_assets_url_key ON public.cms_media_assets USING btree (url);


--
-- Name: cms_nav_items_menu_published_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_nav_items_menu_published_order_idx ON public.cms_nav_items USING btree (menu, published, "order");


--
-- Name: cms_pages_slug_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pages_slug_idx ON public.cms_pages USING btree (slug);


--
-- Name: cms_pages_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cms_pages_slug_key ON public.cms_pages USING btree (slug);


--
-- Name: cms_pages_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pages_status_idx ON public.cms_pages USING btree (status);


--
-- Name: cms_revisions_authorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cms_revisions_authorId_idx" ON public.cms_revisions USING btree ("authorId");


--
-- Name: cms_revisions_pageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cms_revisions_pageId_idx" ON public.cms_revisions USING btree ("pageId");


--
-- Name: cms_revisions_pageId_revisionNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "cms_revisions_pageId_revisionNumber_key" ON public.cms_revisions USING btree ("pageId", "revisionNumber");


--
-- Name: donations_childId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donations_childId_idx" ON public.donations USING btree ("childId");


--
-- Name: donations_momoReference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "donations_momoReference_key" ON public.donations USING btree ("momoReference");


--
-- Name: donations_paymentMethod_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donations_paymentMethod_status_idx" ON public.donations USING btree ("paymentMethod", status);


--
-- Name: donations_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donations_status_createdAt_idx" ON public.donations USING btree (status, "createdAt");


--
-- Name: donations_stripeCheckoutSessionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "donations_stripeCheckoutSessionId_key" ON public.donations USING btree ("stripeCheckoutSessionId");


--
-- Name: donations_stripeInvoiceId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "donations_stripeInvoiceId_key" ON public.donations USING btree ("stripeInvoiceId");


--
-- Name: donations_stripePaymentIntentId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "donations_stripePaymentIntentId_key" ON public.donations USING btree ("stripePaymentIntentId");


--
-- Name: donations_stripeSubscriptionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donations_stripeSubscriptionId_idx" ON public.donations USING btree ("stripeSubscriptionId");


--
-- Name: donations_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "donations_userId_idx" ON public.donations USING btree ("userId");


--
-- Name: history_events_published_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX history_events_published_order_idx ON public.history_events USING btree (published, "order");


--
-- Name: impact_stats_published_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX impact_stats_published_order_idx ON public.impact_stats USING btree (published, "order");


--
-- Name: partnership_inquiries_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "partnership_inquiries_status_createdAt_idx" ON public.partnership_inquiries USING btree (status, "createdAt");


--
-- Name: sessions_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "sessions_sessionToken_key" ON public.sessions USING btree ("sessionToken");


--
-- Name: sessions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sessions_userId_idx" ON public.sessions USING btree ("userId");


--
-- Name: sponsorships_childId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sponsorships_childId_idx" ON public.sponsorships USING btree ("childId");


--
-- Name: sponsorships_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sponsorships_status_idx ON public.sponsorships USING btree (status);


--
-- Name: sponsorships_stripeSubscriptionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "sponsorships_stripeSubscriptionId_key" ON public.sponsorships USING btree ("stripeSubscriptionId");


--
-- Name: sponsorships_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sponsorships_userId_idx" ON public.sponsorships USING btree ("userId");


--
-- Name: stories_published_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stories_published_order_idx ON public.stories USING btree (published, "order");


--
-- Name: trustees_published_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trustees_published_order_idx ON public.trustees USING btree (published, "order");


--
-- Name: users_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "users_createdAt_idx" ON public.users USING btree ("createdAt");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_resetPasswordToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "users_resetPasswordToken_key" ON public.users USING btree ("resetPasswordToken");


--
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_idx ON public.users USING btree (role);


--
-- Name: verification_tokens_identifier_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX verification_tokens_identifier_token_key ON public.verification_tokens USING btree (identifier, token);


--
-- Name: verification_tokens_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX verification_tokens_token_key ON public.verification_tokens USING btree (token);


--
-- Name: accounts accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: child_updates child_updates_childId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.child_updates
    ADD CONSTRAINT "child_updates_childId_fkey" FOREIGN KEY ("childId") REFERENCES public.children(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cms_audit_logs cms_audit_logs_pageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_audit_logs
    ADD CONSTRAINT "cms_audit_logs_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES public.cms_pages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cms_audit_logs cms_audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_audit_logs
    ADD CONSTRAINT "cms_audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cms_media_assets cms_media_assets_uploadedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_media_assets
    ADD CONSTRAINT "cms_media_assets_uploadedBy_fkey" FOREIGN KEY ("uploadedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cms_nav_items cms_nav_items_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_nav_items
    ADD CONSTRAINT "cms_nav_items_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.cms_nav_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cms_revisions cms_revisions_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_revisions
    ADD CONSTRAINT "cms_revisions_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cms_revisions cms_revisions_pageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_revisions
    ADD CONSTRAINT "cms_revisions_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES public.cms_pages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: donations donations_childId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_childId_fkey" FOREIGN KEY ("childId") REFERENCES public.children(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: donations donations_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sponsorships sponsorships_childId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sponsorships
    ADD CONSTRAINT "sponsorships_childId_fkey" FOREIGN KEY ("childId") REFERENCES public.children(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sponsorships sponsorships_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sponsorships
    ADD CONSTRAINT "sponsorships_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 2kRBtmtJkicfwKfdLfkN5SJdphRYeVGoOMd6Kcod1nJRh5l2bNxvANQgpYAoZbM

